
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.timeextraminer.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;

import net.mcreator.timeextraminer.entity.NziScientistEntity;
import net.mcreator.timeextraminer.entity.HansWeberPassiveEntity;
import net.mcreator.timeextraminer.entity.HansWeberHostileEntity;
import net.mcreator.timeextraminer.TimeextraminerMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class TimeextraminerModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.ENTITIES, TimeextraminerMod.MODID);
	public static final RegistryObject<EntityType<NziScientistEntity>> NZI_SCIENTIST = register("nzi_scientist",
			EntityType.Builder.<NziScientistEntity>of(NziScientistEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true)
					.setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(NziScientistEntity::new)

					.sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<HansWeberPassiveEntity>> HANS_WEBER_PASSIVE = register("hans_weber_passive",
			EntityType.Builder.<HansWeberPassiveEntity>of(HansWeberPassiveEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true)
					.setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(HansWeberPassiveEntity::new)

					.sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<HansWeberHostileEntity>> HANS_WEBER_HOSTILE = register("hans_weber_hostile",
			EntityType.Builder.<HansWeberHostileEntity>of(HansWeberHostileEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true)
					.setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(HansWeberHostileEntity::new).fireImmune().sized(0.6f, 1.8f));

	private static <T extends Entity> RegistryObject<EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(registryname));
	}

	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		event.enqueueWork(() -> {
			NziScientistEntity.init();
			HansWeberPassiveEntity.init();
			HansWeberHostileEntity.init();
		});
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(NZI_SCIENTIST.get(), NziScientistEntity.createAttributes().build());
		event.put(HANS_WEBER_PASSIVE.get(), HansWeberPassiveEntity.createAttributes().build());
		event.put(HANS_WEBER_HOSTILE.get(), HansWeberHostileEntity.createAttributes().build());
	}
}
