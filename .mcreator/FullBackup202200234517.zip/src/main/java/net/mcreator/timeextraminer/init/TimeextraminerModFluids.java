
/*
 * MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.timeextraminer.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.level.material.Fluid;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.ItemBlockRenderTypes;

import net.mcreator.timeextraminer.fluid.Helium3fluidFluid;
import net.mcreator.timeextraminer.TimeextraminerMod;

public class TimeextraminerModFluids {
	public static final DeferredRegister<Fluid> REGISTRY = DeferredRegister.create(ForgeRegistries.FLUIDS, TimeextraminerMod.MODID);
	public static final RegistryObject<Fluid> HELIUM_3FLUID = REGISTRY.register("helium_3fluid", () -> new Helium3fluidFluid.Source());
	public static final RegistryObject<Fluid> FLOWING_HELIUM_3FLUID = REGISTRY.register("flowing_helium_3fluid",
			() -> new Helium3fluidFluid.Flowing());

	@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
	public static class ClientSideHandler {
		@SubscribeEvent
		public static void clientSetup(FMLClientSetupEvent event) {
			ItemBlockRenderTypes.setRenderLayer(HELIUM_3FLUID.get(), renderType -> renderType == RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(FLOWING_HELIUM_3FLUID.get(), renderType -> renderType == RenderType.translucent());
		}
	}
}
