
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.timeextraminer.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.mcreator.timeextraminer.client.renderer.NziScientistRenderer;
import net.mcreator.timeextraminer.client.renderer.HansWeberPassiveRenderer;
import net.mcreator.timeextraminer.client.renderer.HansWeberHostileRenderer;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class TimeextraminerModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(TimeextraminerModEntities.NZI_SCIENTIST.get(), NziScientistRenderer::new);
		event.registerEntityRenderer(TimeextraminerModEntities.HANS_WEBER_PASSIVE.get(), HansWeberPassiveRenderer::new);
		event.registerEntityRenderer(TimeextraminerModEntities.HANS_WEBER_HOSTILE.get(), HansWeberHostileRenderer::new);
	}
}
