package net.mcreator.timeextraminer.procedures;

import net.minecraftforge.server.ServerLifecycleHooks;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.server.MinecraftServer;
import net.minecraft.network.chat.TextComponent;
import net.minecraft.network.chat.ChatType;
import net.minecraft.Util;

public class JanotneinProcedure {
	public static void execute(LevelAccessor world) {
		if (!world.isClientSide()) {
			MinecraftServer _mcserv = ServerLifecycleHooks.getCurrentServer();
			if (_mcserv != null)
				_mcserv.getPlayerList().broadcastMessage(new TextComponent(
						"Ok alors une fois que vous avez la bombe, vous devez la ramener et la lancer avec ce lance missile derni\u00E8re g\u00E9n\u00E9ration."),
						ChatType.SYSTEM, Util.NIL_UUID);
		}
	}
}
